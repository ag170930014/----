# 201571030135-201571030137
小学生四则运算
文件解释：
/src:
ContentToTxt():将内容写入文件
ContinuTest（）：询问是否进行下一轮测试
DTimeFrame（）：计时功能
LoginIn（）：登录界面
PrintChart（）：绘制分数图
ReadFile（）：一行一行读文件
UI()：答题界面
/lib:
以下三个包均是用来绘制图形使用的
gnujaxp-1.0.0.jar
jfreechart-1.0.13.jar
jcommon-1.0.16.jar
